package springboot.model;

import java.util.UUID;


/**
 * 
 * @author Andrieux Seraphin
 * Modele de la classe Card qui va contenir toutes les cartes
 * Simple model permettant a notre interface de communiquer des objets de type carte entre les microservices
 *
 */




public class Card {
	
								/* Attributs */

	private int idCard;
	
	private String name;
	private String description;
	private String family;
	private int hp;
	private int energy;
	private int defence;
	private int attack;
	private int price;
	private String imgUrl;
	
			
								/* Constructeurs */
	public Card() {
		
		this.idCard = 0;
		this.name = "";
		this.description = "";
		this.family = "";
		this.hp = 0;
		this.energy = 0;
		this.defence = 0;
		this.attack = 0;
		this.imgUrl = "";
	}
	
	public Card( String name, String description, String family, int hp, int energy, int defence, int attack,
			String imgUrl,int price) {
		
		this.idCard = Integer.valueOf(UUID.randomUUID().toString());
		this.name = name;
		this.description = description;
		this.family = family;
		this.hp = hp;
		this.energy = energy;
		this.defence = defence;
		this.attack = attack;
		this.imgUrl = imgUrl;
		this.price=price;
	}
	
	public Card(int id, String name, String description, String family, int hp, int energy, int defence, int attack,
			String imgUrl) {
		
		this.idCard = id;
		this.name = name;
		this.description = description;
		this.family = family;
		this.hp = hp;
		this.energy = energy;
		this.defence = defence;
		this.attack = attack;
		this.imgUrl = imgUrl;
		this.price =price;
	}

						/* Getters & Setters */
	
	public int getIdCard() {
		return idCard;
	}

	public void setIdCard(int id) {
		this.idCard = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getFamily() {
		return family;
	}

	public void setFamily(String family) {
		this.family = family;
	}

	public int getHp() {
		return hp;
	}

	public void setHp(int hp) {
		this.hp = hp;
	}

	public int getEnergy() {
		return energy;
	}

	public void setEnergy(int energy) {
		this.energy = energy;
	}

	public int getDefence() {
		return defence;
	}

	public void setDefence(int defence) {
		this.defence = defence;
	}

	public int getAttack() {
		return attack;
	}

	public void setAttack(int attack) {
		this.attack = attack;
	}

	public String getImgUrl() {
		return imgUrl;
	}

	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}
	

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Card [idCard=" + idCard + ", name=" + name + ", description=" + description + ", family=" + family
				+ ", hp=" + hp + ", energy=" + energy + ", defence=" + defence + ", attack=" + attack + ", imgUrl="
				+ imgUrl + "]";
	}
	
}
