package springboot.model;


/**
 * 
 * @author Andrieux Seraphin
 * Modele de la classe Utilisateur qui va contenir les infos d'un utilisateur
 * Simple model permettant a notre interface de communiquer des objets de type carte entre les microservices
 *
 */

public class Utilisateur {


    private int id;
	
	private String name;
	private String surname;
	private String password;
	private float money;

 
 	public Utilisateur(int id) {
 		this.id=id;
 		this.setName("");
		this.setSurname("");
		this.setPassword("");
		this.setMoney(10000);
 	}
	public Utilisateur() {

		this.setName("");
		this.setSurname("");
		this.setPassword("");
		this.setMoney(10000);
	}
	
	public Utilisateur( String name,String surname,String password, float money) {
		this.setName(name);
		this.setSurname(surname);
		this.setPassword(password);
		this.setMoney(money);
	}
	public Utilisateur(String name,String password) {
		this.setName(name);
		this.setPassword(password);
		this.setSurname("");
		this.setId(0);
		this.setMoney(0);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public float getMoney() {
		return money;
	}

	public int getId() {
		return id;
	}
	
	public void setMoney(float money) {
		this.money = money;
	}

	public void setId(int id) {
		this.id=id;			
	}
	@Override
	public String toString() {
		return "Utilisateur [id=" + id + ", name=" + name + ", surname=" + surname + ", password=" + password
				+ ", money=" + money + "]";
	}

}