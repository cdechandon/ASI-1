package springboot.model;



import springboot.model.Card;
import springboot.model.Utilisateur;


/**
 * 
 * @author Andrieux Seraphin
 * Modele de la classe CardForUser qui va contenir les cartes des utilisateurs
 * Simple model permettant a notre interface de communiquer des objets de type carte entre les microservices
 *
 */

public class CardForUser {

	private int idCardForUser;
	
	// Attributs communs avec Card
	private int idCard;
	private String name;
	private String description;
	private String family;
	private int hp;
	private int energy;
	private int defence;
	private int attack;
	private String imgUrl;
	private int price;
	private Utilisateur user;
	
	
	
						/* Constructeurs */

	// Sert en pratique à l'ajout d'une nouvelle carte
	public CardForUser(Card card,Utilisateur user) {
		this.idCard=card.getIdCard();
		this.name=card.getName();
		this.description=card.getDescription();
		this.family=card.getFamily();
		this.hp=card.getHp();
		this.energy=card.getEnergy();
		this.defence=card.getDefence();
		this.attack=card.getAttack();
		this.imgUrl=card.getImgUrl();
		this.price=card.getPrice();
		this.user=user;
	}
	
	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	// Sert en pratique à la màj des données d'une carte
	public CardForUser(int idCardForUser,Card card,Utilisateur user) {
		this.idCardForUser=idCardForUser;
		this.idCard=card.getIdCard();
		this.name=card.getName();
		this.description=card.getDescription();
		this.family=card.getFamily();
		this.hp=card.getHp();
		this.energy=card.getEnergy();
		this.defence=card.getDefence();
		this.attack=card.getAttack();
		this.imgUrl=card.getImgUrl();
		this.price=card.getPrice();
		this.user=user;
	}
	
	// Sert en pratique pour les méthodes CardForUserService.getCardForUser()
	public CardForUser(Utilisateur user) 
	{		
		//this.idCardForUser=Integer.valueOf(UUID.randomUUID().toString());
		this.user = user;
		this.idCard = 0;
		this.name = "";
		this.description = "";
		this.family = "";
		this.hp = 0;
		this.energy = 0;
		this.defence = 0;
		this.attack = 0;
		this.imgUrl = "";
		this.price=0;
	}
	
	// JPA
	public CardForUser() 
	{
		this.idCardForUser=0;
		this.user = null;
		this.idCard = 0;
		this.name = "";
		this.description = "";
		this.family = "";
		this.hp = 0;
		this.energy = 0;
		this.defence = 0;
		this.attack = 0;
		this.imgUrl = "";
		this.price=0;
	}

	
	
	 					/* Getters & Setters */

	public Utilisateur getUtilisateur() {
		return user;
	}

	public int getIdCardForUser() {
		return idCardForUser;
	}

	public void setIdCardForUser(int id) {
		this.idCardForUser = id;
	}

	public int getIdCard() {
		return idCard;
	}

	public void setIdCard(int id) {
		this.idCard = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getFamily() {
		return family;
	}

	public void setFamily(String family) {
		this.family = family;
	}

	public int getHp() {
		return hp;
	}

	public void setHp(int hp) {
		this.hp = hp;
	}

	public int getEnergy() {
		return energy;
	}

	public void setEnergy(int energy) {
		this.energy = energy;
	}

	public int getDefence() {
		return defence;
	}

	public void setDefence(int defence) {
		this.defence = defence;
	}

	public int getAttack() {
		return attack;
	}

	public void setAttack(int attack) {
		this.attack = attack;
	}

	public String getImgUrl() {
		return imgUrl;
	}

	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}

	@Override
	public String toString() {
		return "CardForUser [idCardForUser=" + idCardForUser + ", idCard=" + idCard + ", name=" + name
				+ ", description=" + description + ", family=" + family + ", hp=" + hp + ", energy=" + energy
				+ ", defence=" + defence + ", attack=" + attack + ", imgUrl=" + imgUrl + ", user=" + user + "]";
	}
	
	
}
