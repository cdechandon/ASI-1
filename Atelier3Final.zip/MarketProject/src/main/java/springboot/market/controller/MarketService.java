package springboot.market.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import springboot.model.Card;
import springboot.model.CardForUser;
import springboot.model.Utilisateur;



@Service// identifie le bean comme un service
public class MarketService  {
	
	
	
	/**
	 * fonction permettant de vendre une carte
	 * @param cardId Id de la carte
	 * @param userId Id de l'utilisateur
	 */
	public void SellCard(int userId,int cardId) { 
		Utilisateur user = getUser(userId);// on recupere les infos de l'utilisateur
		user.setId(userId);//on injecte son id pour eviter lors du PUT de recreer un utilisateur
		float moneyUser=getUser(userId).getMoney();//on recupere son argent
		moneyUser+=(float)getCardForUser(userId, cardId).getPrice();// on rajoute les sous de la cartes
		user.setMoney(moneyUser);// on change son argent
		updateUser(user);// on actualise l'utilisateur
		deleteCardForUser(userId,cardId);//on supprime la carte vendue dans la DB
		
		
	}
		
	
	/**
	 * fonction permettant d'acheter une carte
	 * @param userId Id de l'utilisateur
	 * @param cardId Id de la carte
	 */
	public void BuyCard( int userId,int cardId) {
		Utilisateur user = getUser(userId);
		user.setId(userId);
		float moneyUser=user.getMoney();
		float priceCard=(float)getCard(cardId).getPrice();
		if (priceCard<moneyUser) {// on verifie que l'utilisateur possede assez d'argent
			addCardForUser(userId, cardId);
			moneyUser -=  priceCard;
			user.setMoney(moneyUser);
			updateUser(user);
		}
		else
		{
			System.out.println("attention pas assez d'argent");
		}
	}
	
	
	/**
	 * methode pour aller dans uservice cards
	 * @return une carte
	 */
	public Card getCard(int id) { 
		Card card=new Card();
		RestTemplate restTemplate = new RestTemplate();		
		String fooResourceUrl = "http://localhost:2020/cards"; //URL de redirection
		fooResourceUrl+="/"+String.valueOf(id);
		try {	
		 card = restTemplate.getForObject(fooResourceUrl, Card.class); //méthode pour récup réponse
		}catch (RestClientException e) {
			e.printStackTrace();
		}
		return card;
	}
	
	
	/**
	 * 
	 * @param userId Id de l'utilisateur
	 * @param cardId Id de la carte
	 * @return une carte de l'utilisateur correspondant à l'Id entré
	 */
	
	
	public CardForUser getCardForUser(int idUser,int idCard) { 
		CardForUser cardForUser=new CardForUser();
		RestTemplate restTemplate = new RestTemplate();		
		String fooResourceUrl = "http://localhost:4040/users"; //URL de redirection
		fooResourceUrl+="/"+String.valueOf(idUser)+"/cards/"+String.valueOf(idCard);
		try {	
		 cardForUser = restTemplate.getForObject(fooResourceUrl, CardForUser.class); //méthode pour récup réponse
		}catch (RestClientException e) {
			e.printStackTrace();
		}
		return cardForUser;
	}
	
	/**
	 * ajouter une carte pour un utilisateur
	 * @param userId Id de l'utilisateur
	 * @param cardId Id de la carte
	 */
	public void addCardForUser(int userId,int cardId) {
		RestTemplate restTemplate = new RestTemplate();
		String fooResourceUrl = "http://localhost:4040/users/"+String.valueOf(userId)+"/cards/"+String.valueOf(cardId);
		try {
					restTemplate.postForEntity(fooResourceUrl,null, null);
		}
		catch(RestClientException e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * enlever une carte à un utilisateur
	 * @param userId Id de l'utilisateur
	 * @param cardId Id de la carte
	 */
	public void deleteCardForUser(int userId,int cardId) {
		RestTemplate restTemplate = new RestTemplate();
		String fooResourceUrl = "http://localhost:4040/users/"+String.valueOf(userId)+"/cards/"+String.valueOf(cardId);
		try {
					restTemplate.delete(fooResourceUrl);
		}
		catch(RestClientException e){
			e.printStackTrace();
		}
		
	}
	
	
	/**
	 * 
	 * @param userId Id de l'utilisateur
	 * @return l'utilisateur correspondant à l'Id rentré
	 */
	public Utilisateur getUser(int userId) {
		Utilisateur utilisateur=null;
		RestTemplate restTemplate = new RestTemplate();
		String fooResourceUrl = "http://localhost:3030/users/"+String.valueOf(userId);
		try {
			utilisateur = restTemplate.getForObject(fooResourceUrl, Utilisateur.class);
		}
		catch (RestClientException e) {
			e.printStackTrace();
		}
		return utilisateur;
	}
	
	
	/**
	 * sauvegarde les changements pour un utilisateur
	 * @param userId Id de l'utilisateur
	 */
	public void updateUser(Utilisateur user) {
		RestTemplate restTemplate = new RestTemplate();
		String fooResourceUrl = "http://localhost:3030/users/"+String.valueOf(user.getId());
		try {
					restTemplate.put(fooResourceUrl,user, Utilisateur.class);;
		}
		catch(RestClientException e){
			e.printStackTrace();
		}
	}
 
}
