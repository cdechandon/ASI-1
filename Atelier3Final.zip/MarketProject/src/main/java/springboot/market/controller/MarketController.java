package springboot.market.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController //Controller de type REST
public class MarketController {
	
	@Autowired //annotation qui nous permet de faire l’injection de dépendances entre les beans de 
	//l’application
	private MarketService marketService;
	
	
	/**
	 * 
	 * @param userId id de l'utilisateur
	 * @param cardId id de la carte
	 */
	@RequestMapping(method=RequestMethod.PUT,value="/sellCard/{userId}/{cardId}") // on ecoute sur notre port si il y a une requete put dont l'uri contient sellcard/userId/cardId
	public void VendreCarte(@PathVariable int userId, @PathVariable int cardId) {
		marketService.SellCard(userId,cardId);
	}
	
	@RequestMapping(method=RequestMethod.PUT,value="/buyCard/{userId}/{cardId}") // on ecoute sur notre port si il y a une requete put dont l'uri contient buycard/userId/cardId
	public void AcheterCarte(@PathVariable int userId, @PathVariable int cardId) {
		marketService.BuyCard(userId,cardId);
	}
	
	
	

}
