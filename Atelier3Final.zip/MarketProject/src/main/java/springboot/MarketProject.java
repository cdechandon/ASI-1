package springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MarketProject {

	public static void main(String[] args) {
		SpringApplication.run(MarketProject.class, args);
	}
}
