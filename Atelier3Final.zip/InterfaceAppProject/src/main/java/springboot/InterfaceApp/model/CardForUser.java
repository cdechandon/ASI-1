package springboot.InterfaceApp.model;

import java.util.UUID;




/**
 * 
 * @author Andrieux Seraphin
 * Modele de la classe CardForUser qui va contenir les cartes des utilisateurs
 * Simple model permettant a notre interface de communiquer des objets de type carte entre les microservices
 *
 */

public class CardForUser {
	private int idCardUser;
	
	public int idCard;
	private String name;
	private String description;
	private String family;
	private int hp;
	private int energy;
	private int defence;
	private int attack;
	private int price;
	private String imgUrl;
	private Utilisateur utilisateur;

	public CardForUser(Utilisateur utilisateur) {
		super();
		this.idCardUser=Integer.valueOf(UUID.randomUUID().toString());
		this.utilisateur = utilisateur;
	}
	
	public CardForUser(Card card,Utilisateur utilisateur) {
		this.idCard=card.getIdCard();
		this.name=card.getName();
		this.description=card.getDescription();
		this.family=card.getFamily();
		this.hp=card.getHp();
		this.energy=card.getEnergy();
		this.defence=card.getDefence();
		this.attack=card.getAttack();
		this.imgUrl=card.getImgUrl();
		this.utilisateur=utilisateur;
	}
	public CardForUser(int id1,Card card,Utilisateur utilisateur) {
		this.idCardUser=id1;
		this.idCard=card.getIdCard();
		this.name=card.getName();
		this.description=card.getDescription();
		this.family=card.getFamily();
		this.hp=card.getHp();
		this.energy=card.getEnergy();
		this.defence=card.getDefence();
		this.attack=card.getAttack();
		this.imgUrl=card.getImgUrl();
		this.utilisateur=utilisateur;
	}
	
	public CardForUser() {
		
	}

	public Utilisateur getUtilisateur() {
		return utilisateur;
	}

	public void setUtilisateur(Utilisateur utilisateur) {
		this.utilisateur = utilisateur;
	}

	public int getIdCardUser() {
		return idCardUser;
	}

	public void setIdCardUser(int id) {
		this.idCardUser = id;
	}

	public int getId() {
		return idCard;
	}

	public void setId(int id) {
		this.idCard = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getFamily() {
		return family;
	}

	public void setFamily(String family) {
		this.family = family;
	}

	public int getHp() {
		return hp;
	}

	public void setHp(int hp) {
		this.hp = hp;
	}

	public int getEnergy() {
		return energy;
	}

	public void setEnergy(int energy) {
		this.energy = energy;
	}

	public int getDefence() {
		return defence;
	}

	public void setDefence(int defence) {
		this.defence = defence;
	}

	public int getAttack() {
		return attack;
	}

	public void setAttack(int attack) {
		this.attack = attack;
	}

	public String getImgUrl() {
		return imgUrl;
	}

	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

}
