package springboot.InterfaceApp.service;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

/**
 * Service pour l'interface dedie au microservice Market, celui generera les bonnes requetes
 * pour que le micro service correspondant effectue les bonnes operations
 * Le microservice Market se situe sur le port 5050 de localhost
 * @author andrieux
 *
 */
@Service // indique au controller qu'il s'agit d'un service
public class InterfaceAppMarketService {
	
	public void buyCard(int idUser,int idCard) {
		RestTemplate restTemplate = new RestTemplate();		
		String fooResourceUrl = "http://localhost:5050/buyCard/"+idUser+"/"+idCard; //URL de redirection
		try {	
			restTemplate.put(fooResourceUrl, null);
		}catch (RestClientException e) {
			e.printStackTrace();
		}
		
	}
	public void sellCard(int idUser,int idCard) {
		RestTemplate restTemplate = new RestTemplate();		
		String fooResourceUrl = "http://localhost:5050/sellCard/"+idUser+"/"+idCard; //URL de redirection
		try {	
			restTemplate.put(fooResourceUrl,null);
		}catch (RestClientException e) {
			e.printStackTrace();
		}
		
	}

}
