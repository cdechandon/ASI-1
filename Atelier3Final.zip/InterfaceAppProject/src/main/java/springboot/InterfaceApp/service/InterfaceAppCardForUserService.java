package springboot.InterfaceApp.service;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import springboot.InterfaceApp.model.Card;
import springboot.InterfaceApp.model.CardForUser;


/**
 * Service pour l'interface dedie au microservice CardForUser, celui generera les bonnes requetes
 * pour que le micro service correspondant effectue les bonnes operations
 * Le microservice CardForUser se situe sur le port 4040 de localhost
 * @author andrieux
 *
 */
@Service 
public class InterfaceAppCardForUserService {
	
	/**
	 * return une liste des cartes d'un utilisateur
	 */
	public List<CardForUser> getAllCardsForUser(int idUser) { 
		List<CardForUser> cardList=new ArrayList<>();
		CardForUser[] cardForUsertab=null	; //intialise la cardtab au cas où elle est vide
		RestTemplate restTemplate = new RestTemplate();		
		String fooResourceUrl = "http://localhost:4040/users/"+String.valueOf(idUser)+"/cards"; //URL de redirection
		try {	
			cardForUsertab = restTemplate.getForObject(fooResourceUrl, CardForUser[].class); //méthode pour récup réponse
		}catch (RestClientException e) {
			e.printStackTrace();
		}
		for (CardForUser cardForUser : cardForUsertab) { //on remplit la liste de cartes
			cardList.add(cardForUser);
		}
		return cardList;
	}

	/**
	 * requete envoyant une carte a ajoute
	 * @param userId
	 * @param cardId
	 */
	public void addCardForUser(int userId,int cardId) { 
		RestTemplate restTemplate = new RestTemplate();		
		String fooResourceUrl = "http://localhost:4040/users/"; //URL de redirection
		fooResourceUrl+=String.valueOf(userId)+"/cards/"+String.valueOf(cardId);
		try {	
			restTemplate.postForEntity(fooResourceUrl, null,null); //méthode pour envoyer une requete de type post avec aucun objet ( d'ou le null,null)
		}catch (RestClientException e) {
			e.printStackTrace();
		}
	}
	
	public CardForUser getCardForUser(int idUser,int idCard) { 
		CardForUser cardForUser=new CardForUser();
		RestTemplate restTemplate = new RestTemplate();		
		String fooResourceUrl = "http://localhost:4040/users"; //URL de redirection
		fooResourceUrl+="/"+String.valueOf(idUser)+"/cards/"+String.valueOf(idCard);
		try {	
		 cardForUser = restTemplate.getForObject(fooResourceUrl, CardForUser.class); //méthode pour récup réponse car requete get avec une reponse de type CardForUser
		}catch (RestClientException e) {// si jamais il y a une erreur
			e.printStackTrace();
		}
		return cardForUser;
	}
	
	public void updateCardForUser(Card card, int idUser,int idCard) {
		RestTemplate restTemplate = new RestTemplate();		
		String fooResourceUrl = "http://localhost:4040/users"; //URL de redirection
		fooResourceUrl+="/"+String.valueOf(idUser)+"/cards/"+String.valueOf(idCard);
		try {	
			restTemplate.put(fooResourceUrl, card);// methode put en envoyant la carte a modifie
		}catch (RestClientException e) {
			e.printStackTrace();
		}
		
	}

	public void deleteCardForUser(int idUser,int idCard) {
		RestTemplate restTemplate = new RestTemplate();		
		String fooResourceUrl = "http://localhost:4040/users/"+String.valueOf(idUser)+"/cards/"+String.valueOf(idCard); //URL de redirection
		try {	
			restTemplate.delete(fooResourceUrl);
		}catch (RestClientException e) {
			e.printStackTrace();
		}
		
	}

	public String getUserConnexion(String surname) {
		String message="";
		RestTemplate restTemplate = new RestTemplate();		
		System.out.println(surname);
		String fooResourceUrl = "http://localhost:3030/ConnexionUsers/"+surname; //URL de redirection
		System.out.println(fooResourceUrl);
		try {	
		 message = restTemplate.getForObject(fooResourceUrl, String.class); //méthode pour récup réponse
		}catch (RestClientException e) {
			e.printStackTrace();
		}
		System.out.println("Mot de passe : "+message);
		return message;
	}
}
