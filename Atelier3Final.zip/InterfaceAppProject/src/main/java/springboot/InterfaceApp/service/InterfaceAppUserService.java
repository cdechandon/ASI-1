package springboot.InterfaceApp.service;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import springboot.InterfaceApp.model.Utilisateur;

/**
 * Service pour l'interface dedie au microservice Utilisateur, celui generera les bonnes requetes
 * pour que le micro service correspondant effectue les bonnes operations
 * Le microservice Utilisateur se situe sur le port 3030 de localhost
 * @author andrieux
 *
 */

@Service 
public class InterfaceAppUserService {
	
	public Utilisateur getUser(int id) { 
		Utilisateur user=new Utilisateur();
		RestTemplate restTemplate = new RestTemplate();		
		String fooResourceUrl = "http://localhost:3030/users"; //URL de redirection
		fooResourceUrl+="/"+String.valueOf(id);
		try {	
		 user = restTemplate.getForObject(fooResourceUrl, Utilisateur.class); //méthode pour récup réponse
		}catch (RestClientException e) {
			e.printStackTrace();
		}
		return user;
	}
	
	public void addUser(Utilisateur user) { 
		RestTemplate restTemplate = new RestTemplate();		
		String fooResourceUrl = "http://localhost:3030/users"; //URL de redirection
		try {	
			restTemplate.postForObject(fooResourceUrl,user ,Utilisateur.class); //méthode pour récup réponse
		}catch (RestClientException e) {
			e.printStackTrace();
		}
	}
	
	public void updateUser(Utilisateur user, int id) {
		RestTemplate restTemplate = new RestTemplate();		
		String fooResourceUrl = "http://localhost:3030/users"; //URL de redirection
		fooResourceUrl+="/"+String.valueOf(id);
		try {	
			restTemplate.put(fooResourceUrl, user);
		}catch (RestClientException e) {
			e.printStackTrace();
		}
	}
	
	public void deleteUser(int id) {
		RestTemplate restTemplate = new RestTemplate();		
		String fooResourceUrl = "http://localhost:3030/users"; //URL de redirection
		fooResourceUrl+="/"+String.valueOf(id);
		try {	
			restTemplate.delete(fooResourceUrl);
		}catch (RestClientException e) {
			e.printStackTrace();
		}
		
	}
}
