package springboot.InterfaceApp.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import springboot.InterfaceApp.model.Card;

/**
 * Service pour l'interface dedie au microservice Card, celui generera les bonnes requetes
 * pour que le micro service correspondant effectue les bonnes operations
 * Le microservice Card se situe sur le port 2020 de localhost
 * @author andrieux
 *
 */
@Service 
public class InterfaceAppCardService {
	/**
	 * methode pour aller dans uservice cards
	 * @return list cards
	 */
	public List<Card> getAllCards() { 
		List<Card> cardList=new ArrayList<>();
		Card[] cardtab=null	; //intialise la cardtab au cas où elle est vide
		RestTemplate restTemplate = new RestTemplate();		
		String fooResourceUrl = "http://localhost:2020/cards"; //URL de redirection
		try {	
		 cardtab = restTemplate.getForObject(fooResourceUrl, Card[].class).clone(); //méthode pour récup réponse
		}catch (RestClientException e) {
			e.printStackTrace();
		}
		int i=0;
		for (Card card : cardtab) { //on remplit la liste de cartes
			cardList.add(card);
			card.setIdCard(cardtab[i].id);
			i++;
		}
		return cardList;
	}

	/**
	 * methode pour aller dans uservice cards
	 * @return une carte
	 */
	public Card getCard(int id) { 
		Card card=new Card();
		RestTemplate restTemplate = new RestTemplate();		
		String fooResourceUrl = "http://localhost:2020/cards"; //URL de redirection
		fooResourceUrl+="/"+String.valueOf(id);
		try {	
		 card = restTemplate.getForObject(fooResourceUrl, Card.class); //méthode pour récup réponse
		}catch (RestClientException e) {
			e.printStackTrace();
		}
		return card;
	}
	/**
	 * methode pour aller dans uservice cards
	 * @return une carte
	 */
	public void addCard(Card card) { 
		RestTemplate restTemplate = new RestTemplate();		
		String fooResourceUrl = "http://localhost:2020/cards"; //URL de redirection
		try {	
			restTemplate.postForObject(fooResourceUrl,card ,Card.class); //méthode pour récup réponse
		}catch (RestClientException e) {
			e.printStackTrace();
		}
	}

	public void updateCard(Card card, int id) {
		RestTemplate restTemplate = new RestTemplate();		
		String fooResourceUrl = "http://localhost:2020/cards"; //URL de redirection
		fooResourceUrl+="/"+String.valueOf(id);
		try {	
			restTemplate.put(fooResourceUrl, card);
		}catch (RestClientException e) {
			e.printStackTrace();
		}
		
	}

	public void deleteCard(int id) {
		RestTemplate restTemplate = new RestTemplate();		
		String fooResourceUrl = "http://localhost:2020/cards"; //URL de redirection
		fooResourceUrl+="/"+String.valueOf(id);
		try {	
			restTemplate.delete(fooResourceUrl);
		}catch (RestClientException e) {
			e.printStackTrace();
		}
		
	}
}
