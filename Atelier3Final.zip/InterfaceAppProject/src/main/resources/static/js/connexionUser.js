function connexionUser1(){
        //On recup les données entrées pas l'utilisateur dans le formulaire de connexion
        var surname=document.getElementsByName("surname")[0].value;
        var password=document.getElementsByName("password")[0].value;
  
        var xhr = new XMLHttpRequest();//On envoie une requête http
        xhr.open("GET",'/ConnexionUsers/'+surname,true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
       
       xhr.onreadystatechange = function() {
            if (xhr.readyState == 4 && (xhr.status == 200 || xhr.status == 0)) {
            	//alert(surname+password);
            	//alert("1"+xhr.responseText);
              
            }
    };
    
    xhr.send();
    xhr.addEventListener('readystatechange', function() {
        
    	if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {

    		   if(xhr.responseText==password){
    		    	alert("successssssssssss")
    		    }
    		    else{
    		    	alert(":(")
    		    }

        }
        

    });
  
    //alert(xhr.responseText);
 
	
}