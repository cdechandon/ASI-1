$(document ).ready(function(){
	
	 var xhrc = new XMLHttpRequest();//On envoie une requête http
	    xhrc.open("GET",'/user/1',true);//on indique la méthode qu'on utilise
	    xhrc.responseType = 'json';
	    xhrc.send();
	    xhrc.onreadystatechange = function () {//vérifie que la requête a eu un succès
	        if(xhrc.readyState === XMLHttpRequest.DONE && xhrc.status === 200)
	{//on attend la fin de la requête et on vérife qu'il n'y a pas

	            xhrc.onload = function() {
	            	  var rep = xhrc.response;
	            	    var div1 = document.getElementById("userNameId"); //TODO si on a une session recuperer directement le nom de l'utilisateur 
	            	    div1.textContent = JSON.stringify(rep.name);  
	            	    var text1 = div1.textContent; 
	            	    var div = document.getElementById("compteB"); //TODO si on a une session recuperer directement le nom de l'utilisateur 
	            	    div.textContent = JSON.stringify(rep.money);  
	            	    var text = div.textContent; 
	        				};
	   
	            		  }
	      };
	
	
	
	
	
    var xhr = new XMLHttpRequest();//On envoie une requête http
    xhr.open("GET",'/cards',true);//on indique la méthode qu'on utilise
    xhr.responseType = 'json';
    xhr.send();
    xhr.onreadystatechange = function () {//vérifie que la requête a eu un succès
        if(xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200)
{//on attend la fin de la requête et on vérife qu'il n'y a pas
//d'erreurs
                //alert("request success");
        }
      };
    var listCard = [];
    xhr.onload = function() {
    	  var tab = xhr.response;
    	  
    	  for (var i = 0; i < tab.length; i++) {
    		  var card = {
    				  id: JSON.stringify(tab[i].idCard),
    				    name: JSON.stringify(tab[i].name),
    				   
    				    description: JSON.stringify(tab[i].description),

    				    family: JSON.stringify(tab[i].family),

    				    hp: JSON.stringify(tab[i].hp),

    				    defense: JSON.stringify(tab[i].defence),
    				    energy: JSON.stringify(tab[i].energy),
    				    attack: JSON.stringify(tab[i].attack),
    				    imgUrl: JSON.stringify(tab[i].imgUrl),
    				    price: JSON.stringify(tab[i].price)

    				};
    		    listCard.push(card);
    		    

    		    
    		  }
    	  for(i=0;i<listCard.length;i++){
  	        addCardToList(listCard[i].id,"https://upload.wikimedia.org/wikipedia/commons/thumb/1/1c/DC_Comics_logo.png/280px-DC_Comics_logo.png",listCard[i].family,listCard[i].url,listCard[i].name,
  	        		listCard[i].description,listCard[i].hp,listCard[i].energy,listCard[i].attack,listCard[i].defense,listCard[i].price);
  	    }
    	
    }
    fillCurrentCard("https://upload.wikimedia.org/wikipedia/commons/thumb/1/1c/DC_Comics_logo.png/280px-DC_Comics_logo.png",listCard[0].family,listCard[0].url,listCard[0].name,
      		listCard[0].description,listCard[0].hp,listCard[0].energy,listCard[i].attack,listCard[i].defense,listCard[0].price);

});



function fillCurrentCard(imgUrlFamily,familyName,imgUrl,name,description,hp,energy,attack,defence,price){
    //FILL THE CURRENT CARD
    $('#cardFamilyImgId')[0].src=imgUrlFamily;
    $('#cardFamilyNameId')[0].innerText=familyName;
    $('#cardImgId')[0].src=imgUrl;
    $('#cardNameId')[0].innerText=name;
    $('#cardDescriptionId')[0].innerText=description;
    $('#cardHPId')[0].innerText=hp+" HP";
    $('#cardEnergyId')[0].innerText=energy+" Energy";
    $('#cardAttackId')[0].innerText=attack+" Attack";
    $('#cardDefenceId')[0].innerText=defence+" Defence";
    $('#cardPriceId')[0].innerText=price+" $";
};


function addCardToList(idCard,imgUrlFamily,familyName,imgUrl,name,description,hp,energy,attack,defence,price){
    var nameIdCard="nameIdCard";
	content="\
    <td> \
    <img  class='ui avatar image' src='"+imgUrl+"'> <span id='"+nameIdCard+"'>"+name+" </span> \
   </td> \
    <td>"+description+"</td> \
    <td>"+familyName+"</td> \
    <td>"+hp+"</td> \
    <td>"+energy+"</td> \
    <td>"+defence+"</td> \
    <td>"+attack+"</td> \
    <td>"+price+"$</td>\
    <td>\
        <div class='ui vertical animated button' id='buttonId"+idCard+"' tabindex='0'>\
            <div class='hidden content' >Buy</div>\
    <div class='visible content'>\
        <i class='shop icon'></i>\
    </div>\
    </div>\
    </div>\
    </td>";
    
    $('#cardListId tr:last').after('<tr>'+content+'</tr>');
    $("#buttonId"+idCard).click(function(){
        alert("achat effectue ! ");
        var xhrT = new XMLHttpRequest();//On envoie une requête http
        xhrT.open("PUT",'/market/buy/1/'+idCard,true);//on indique la méthode qu'on utilise
        xhrT.responseType = 'json';
        xhrT.send();
        xhrT.onreadystatechange = function () {//vérifie que la requête a eu un succès
            if(xhrT.readyState === XMLHttpRequest.DONE && xhrT.status === 200)
    {//on attend la fin de la requête et on vérife qu'il n'y a pas
    //d'erreurs
                location.reload(true);
            }
          };
    }); 
    
};



