function addUser1(){
        //On recup les données entrées pas l'utilisateur dans le formulaire
        var name=document.getElementsByName("name")[0].value;
        var surname=document.getElementsByName("surname")[0].value;
        var password=document.getElementsByName("password")[0].value;
        //var  money=10000;
        //float f = Float.parseFloat("25");
        //String s = Float.toString(25.0f);
        


        var xhr = new XMLHttpRequest();//On envoie une requête http
        xhr.open("POST",'/user',true);//on indique la méthode qu'on utilise
        xhr.setRequestHeader("Content-Type", "application/json");

         var data =JSON.stringify({
"name":String(name),"surname":String(surname)
,"password":String(password),"money":10000});//on normalise au format JSON
         xhr.onreadystatechange = function () {//vérifie que la requête a eu un succès
                  if(xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200)
{//on attend la fin de la requête et on vérife qu'il n'y a pas
//d'erreurs
                          alert("Vous etes bien inscrit");
                  }
                };

        xhr.send(data);


}