$(document ).ready(function(){
    var xhrc = new XMLHttpRequest();//On envoie une requête http
    xhrc.open("GET",'/user/1',true);//on indique la méthode qu'on utilise
    xhrc.responseType = 'json';
    xhrc.send();
    xhrc.onreadystatechange = function () {//vérifie que la requête a eu un succès
        if(xhrc.readyState === XMLHttpRequest.DONE && xhrc.status === 200)
{//on attend la fin de la requête et on vérife qu'il n'y a pas

            xhrc.onload = function() {
            	  var rep = xhrc.response;
            	    var div1 = document.getElementById("userNameId"); //TODO si on a une session recuperer directement le nom de l'utilisateur 
            	    div1.textContent = JSON.stringify(rep.name);  
            	    var text1 = div1.textContent; 
            	    var div = document.getElementById("compteB"); //TODO si on a une session recuperer directement le nom de l'utilisateur 
            	    div.textContent = JSON.stringify(rep.money);  
            	    var text = div.textContent; 
        				};
   
            		  }
      };
	
	
	
    $("#playButtonId").click(function(){
        //TO DO
    });    
    $("#buyButtonId").click(function(){
        document.location.href="./Card.html";	//direction vers la nouvelle page html
        //TO DO
    });    
    $("#sellButtonId").click(function(){
        document.location.href="./cardList.html"; //direction vers la nouvelle page html
        //TO DO
    });    
});

