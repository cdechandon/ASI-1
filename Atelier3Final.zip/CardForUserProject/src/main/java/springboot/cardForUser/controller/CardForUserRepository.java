package springboot.cardForUser.controller;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import springboot.cardForUser.model.CardForUser;
import springboot.utilisateur.model.Utilisateur;

/*
 * Crud permet de réaliser des opérations sur la BD
 * CrudRepository est une interface qui permet de faire des opérations comme ajouter une ligne dans la table Card en fonction de son id
 */

public interface CardForUserRepository extends CrudRepository<CardForUser, Integer> {

	/**
	 * 
	 * @param user a partir d'un utilisateur
	 * @return une liste de carte appartenant a celui-ci
	 */
	public List<CardForUser> findByUser(Utilisateur user);

}

