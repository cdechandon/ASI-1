package springboot.cardForUser.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import springboot.card.model.Card;
import springboot.cardForUser.model.CardForUser;
import springboot.utilisateur.model.Utilisateur;


@Service // Indique que cette classe est un service
public class CardForUserService {
	
	@Autowired // nous met en lien avec le repertoire de carte connectee a la db
	private CardForUserRepository cardForUserRepository;
	
	/**
	 * Renvoie une liste de toutes les cartes de l'utilisateur donné
	 * 
	 * @param idUser
	 * @return List<CardForUser>
	 */
	public List<CardForUser> getAllCardForUser(int idUser){
		List<CardForUser> cardForUserList = new ArrayList<>();
		cardForUserRepository.findByUser(getUser(idUser)).forEach(cardForUserList::add);
		return cardForUserList;
	}
	
	/**
	 * Renvoie une carte de l'utilisateur donné
	 * 
	 * @param idUser
	 * @param idCard
	 * @return CardForUser
	 */
	public CardForUser getCardForUser(int idUser,int idCard) 
	{
		// On récupère toutes les cartes de l'utilisateur
		List<CardForUser> cardForUserList = getAllCardForUser(idUser);
		CardForUser cardForUser = new CardForUser(getUser(idUser));

		for(int count=0;count<cardForUserList.size();count++) 
		{
			// Si une carte de la liste a un id correspondant, on la met dans cardForUser
			if (cardForUserList.get(count).getIdCard()==idCard)
			{
				cardForUser = cardForUserList.get(count);
			}
		}
		return cardForUser;
	}
	
	
	/**
	 * Ajoute cardForUser à la table correspondante
	 * 
	 * @param cardForUser
	 */
	public void addCardForUser(CardForUser cardForUser) 
	{
		
		cardForUserRepository.save(cardForUser);
	}
	
	/**
	 * Met à jour cardForUser dans la table correspondante
	 * 
	 * @param cardForUser
	 */

	public void updateCardForUser(CardForUser cardForUser) 
	{
		
		cardForUserRepository.save(cardForUser);
	}

	/**
	 * Efface la carte d'id = idCardForUser de la table correspondante
	 * 
	 * @param idCardForUser
	 */
	public void deleteCardForUser(CardForUser cardForUser) 
	{
		cardForUserRepository.delete(cardForUser);
	}

	/**
	 * 
	 * @param idCard
	 * @return la carte correspondant a son id
	 */
	public Card getCard(int idCard) {
		Card card=new Card();
		RestTemplate restTemplate = new RestTemplate();		
		String fooResourceUrl = "http://localhost:2020/cards"; //URL de redirection
		fooResourceUrl+="/"+String.valueOf(idCard);
		try {	
		 card = restTemplate.getForObject(fooResourceUrl, Card.class); //méthode pour récup réponse
		}catch (RestClientException e) {
			e.printStackTrace();
		}
		return card;
	}
	/**
	 * 
	 * @param id de l'utilisateur
	 * @return l'utilisateur associe a l'id passe en parametre
	 */
	public Utilisateur getUser(int id) { 
		Utilisateur user=new Utilisateur();
		RestTemplate restTemplate = new RestTemplate();		
		String fooResourceUrl = "http://localhost:3030/users"; //URL de redirection vers le bon microservice
		fooResourceUrl+="/"+String.valueOf(id);
		try {	
		 user = restTemplate.getForObject(fooResourceUrl, Utilisateur.class); //méthode pour récup réponse
		}catch (RestClientException e) {
			e.printStackTrace();
		}
		user.setId(id);
		return user;
	}

}
