package springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CardForUserProject {

	public static void main(String[] args) {
		SpringApplication.run(CardForUserProject.class, args);
	}
}
