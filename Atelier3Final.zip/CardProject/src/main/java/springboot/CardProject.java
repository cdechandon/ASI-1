package springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CardProject {

	public static void main(String[] args) {
		SpringApplication.run(CardProject.class, args);
	}
}
