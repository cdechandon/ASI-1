package springboot.card.controller;


import org.springframework.data.repository.CrudRepository;

import springboot.card.model.Card;



/*
 * Crud permet de réaliser des opérations sur la BD
 * CrudRepository est une interface qui permet de faire des opérations comme ajouter une ligne dans la table Card en fonction de son id
 */
public interface CardRepository extends CrudRepository<Card, Integer> {// Nous alons creer un repertoire de carte identifiable par leur id
	
	


}
