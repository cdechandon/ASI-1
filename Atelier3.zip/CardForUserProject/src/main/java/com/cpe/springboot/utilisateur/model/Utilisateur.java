package com.cpe.springboot.utilisateur.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity // a notre DB comment creer la table
public class Utilisateur {


	@Id //clé primaire  pour la base de donnée
	@GeneratedValue(strategy=GenerationType.AUTO) // valeur générée automatiquement 1 par 1
    private int id;
	
	private String name;
	private String surname;
	private String password;
	private float money;

 
 	public Utilisateur(int id) {
 		this.id=id;
 		this.setName("");
		this.setSurname("");
		this.setPassword("");
		this.setMoney(10000);
 	}
	public Utilisateur() {

		this.setName("");
		this.setSurname("");
		this.setPassword("");
		this.setMoney(10000);
	}
	
	public Utilisateur( String name,String surname,String password, float money) {
		this.setName(name);
		this.setSurname(surname);
		this.setPassword(password);
		this.setMoney(money);
	}
	public Utilisateur(String name,String password) {
		this.setName(name);
		this.setPassword(password);
		this.setSurname("");
		this.setId(0);
		this.setMoney(0);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public float getMoney() {
		return money;
	}

	public void setMoney(float money) {
		this.money = money;
	}

	public void setId(int id) {
		this.id=id;			
	}
	@Override
	public String toString() {
		return "Utilisateur [id=" + id + ", name=" + name + ", surname=" + surname + ", password=" + password
				+ ", money=" + money + "]";
	}

}