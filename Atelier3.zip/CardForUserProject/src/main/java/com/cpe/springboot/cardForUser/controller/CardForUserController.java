package com.cpe.springboot.cardForUser.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cpe.springboot.card.model.Card;
import com.cpe.springboot.cardForUser.model.CardForUser;
import com.cpe.springboot.utilisateur.model.Utilisateur;


/*
 * Controller Restful -> gère les requêtes http du type methodes get, post, put et delete et renvoie une page JSON
 */

@RestController
public class CardForUserController {


	
	// Déclare un service utilisé
	@Autowired 
	private CardForUserService cardForUserService;
	
	/**
	 * Récupère toutes les cartes correspondant à l'idUser fourni depuis
	 * <P> la table CardForUser
	 * @param idUser
	 * @return
	 */
	// Fait appel à cette méthode quand l'URL se termine par /cards
	// On utilise la méthode GET par défaut
	@RequestMapping("/users/{idUser}/cards") 
	private List<CardForUser> getAllCardsForUser(@PathVariable int idUser) {
		return cardForUserService.getAllCardForUser(idUser);
	}
	
	/**
	 * Récupère la carte correspondant aux ids fournis depuis
	 * <P> la table CardForUser
	 * 
	 * @param idCard
	 * @param idUser
	 * @return cardForUser
	 */
	
	/* @PathVariable récupère la variable passée en paramètre dans l'URL
	 * On rajoute une variable {id}
	 */
	
	@RequestMapping("/users/{userId}/cards/{idCard}") 
	private CardForUser getCardForUser(@PathVariable int idCard ,@PathVariable String userId ){ 
		return cardForUserService.getCardForUser(Integer.valueOf(userId),idCard);

	}
	
	
	/**
	 * Ajoute la carte associée à l'idCard via cardService,
	 * <P> et à l'idUser donné dans la table CardForUser
	 * 
	 * @param idUser
	 * @param idCard
	 */
	// POST rajoute une ligne dans la table CardForUser
	@RequestMapping(method=RequestMethod.POST,value="/users/{idUser}/cards/{idCard}")
	private void addCardForUser(@PathVariable String idUser,@PathVariable int idCard) {
		// Template de la carte contenu dans la table Cards
		Card card = cardForUserService.getCard(idCard);
		card.setIdCard(idCard);
		// Crée une carte utilisateur à partir de ce template, et de l'idUser
		Utilisateur user=cardForUserService.getUser(Integer.valueOf(idUser));
		user.setId(Integer.valueOf(idUser));
		//System.out.println(user.toString());
		CardForUser cardForUser = new CardForUser(card,user);
		cardForUserService.addCardForUser(cardForUser);
	}
	
	/**
	 * Récupère en paramètre les données à màj, et les remplace
	 * <P> dans la ligne correspondant à l'idCardUser (déterminé
	 * <P> par idCard, et idUser)
	 * 
	 * @param card
	 * @param idCard
	 * @param idUser
	 */
	// PUT modifie les informations correspondant aux ids rentrés
	@RequestMapping(method=RequestMethod.PUT,value="/users/{idUser}/cards/{idCard}")
	private void updateCardForUser(@RequestBody Card card,@PathVariable int idCard,@PathVariable String idUser) {
		// Détermine idCardUser
		int idCardForUser = cardForUserService.getCardForUser(Integer.valueOf(idUser),idCard).getIdCardForUser();
		// Crée une nouvelle cardForUser à partir des données fournies, et écrase
		// celle possédant le même idCarduser
		Utilisateur user=cardForUserService.getUser(Integer.valueOf(idUser));
		user.setId(Integer.valueOf(idUser));
		CardForUser cardForUser = new CardForUser(idCardForUser,card,user);
		cardForUserService.updateCardForUser(cardForUser);
	}
	
	/**
	 * Efface la carte correspondant aux ids donnés
	 * 
	 * @param idUser
	 * @param idCard
	 */
	@RequestMapping(method=RequestMethod.DELETE,value="/users/{idUser}/cards/{idCard}")// Supprime la ligne correspondant à l'id
	private void deleteCardForUser(@PathVariable int idUser,@PathVariable int idCard) {
		// Détermine idCardUser
		int idCardForUser = cardForUserService.getCardForUser(Integer.valueOf(idUser),idCard).getIdCardForUser();
		Card card = new Card();
		Utilisateur user=cardForUserService.getUser(idUser);
		user.setId(idUser);
		CardForUser cardForUser = new CardForUser(idCardForUser, card, user);
		cardForUserService.deleteCardForUser(cardForUser);
	}
}
