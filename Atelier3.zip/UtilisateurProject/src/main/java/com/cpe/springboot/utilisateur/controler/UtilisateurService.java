package com.cpe.springboot.utilisateur.controler;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.log;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cpe.springboot.utilisateur.model.Utilisateur;
import com.mysql.jdbc.log.Log;

@Service // L'application Spring Boot sait que cette classe correspond à un service
public class UtilisateurService {
	
	@Autowired // nous met en lien avec le repertoire de carte connectee a la db
	private UtilisateurRepository utilisateurRepository;
	
	
	/**
	 * 
	 * @return la liste de tout les utilisateurs
	 */
	public List<Utilisateur> getAllUsers(){
		List<Utilisateur> utilisateurs = new ArrayList<>();
		utilisateurRepository.findAll()
		.forEach(utilisateurs::add);
		return utilisateurs;
		
	}
	
	/**
	 * 
	 * @param id de l'utilisateur à recupere
	 * @return  un utilisateur par son id
	 */
	public Utilisateur getUser(int id) {
		//return topics.stream().filter(t -> t.getId().equals(id)).findFirst().get();
		return utilisateurRepository.findOne(id);
	}

	public void addUser(Utilisateur utilisateur) {
		//Utilisateur user= new Utilisateur()
		utilisateurRepository.save(utilisateur);
		
	}

	public void updateUser(Utilisateur utilisateur,int id) {
		utilisateurRepository.save(utilisateur);
		
	}

	public void deleteUser(int id) {
		utilisateurRepository.delete(id);
	}

	public String getUserConnexion(String surname) {
		Utilisateur utilisateur=utilisateurRepository.findBysurname(surname);
	
			return utilisateur.getPassword();
		
		
	}
}
