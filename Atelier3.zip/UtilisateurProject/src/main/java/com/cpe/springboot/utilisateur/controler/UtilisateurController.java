package com.cpe.springboot.utilisateur.controler;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cpe.springboot.utilisateur.model.Utilisateur;

/*
 * Controller Restful -> gère les requêtes http du type methodes get, post, put et delete et renvoie une page JSON
 */
@RestController 
public class UtilisateurController {
	
	

	
	@Autowired // déclare le service qu'on utilise. Fait le lien entre le controller et une instance de UtilisateurService
	private UtilisateurService utilisateurService;
	
	/**
	 * 
	 * @return la liste des utilisateurs
	 * 
	 **/
	@RequestMapping("/users") //mapping methode get pour afficher tous les utilisateurs
	public List<Utilisateur> getAllUsers() {
		
		return utilisateurService.getAllUsers();
	}
	
	
	
	//@PathVariable permet d'indiquer une vqriqble dans l'URL
	/**
	 * 
	 * @param id identifiant de l'utilisateur
	 */
	@RequestMapping("/users/{id}")//mapping methode get pour afficher les infos sur l'utilisateur
	public Utilisateur getUser(@PathVariable int id) {	
		return utilisateurService.getUser(id);
	}
	
	
	@RequestMapping(value="/ConnexionUsers/{surname}")//mapping methode get pour afficher les infos sur l'utilisateur
	public String getUserConnexion(@PathVariable String surname) {	
		System.out.println("password surname : \n"+surname);
		return utilisateurService.getUserConnexion(surname);
	}
	
	
	/**
	 * 
	 * @param utilisateur utilisateur à ajouter à la DB
	 */
	@RequestMapping(method=RequestMethod.POST,value="/users") //mapping methode POST pour rajouter un utilisateur
	public void addUser(@RequestBody Utilisateur utilisateur) {
		utilisateurService.addUser(utilisateur);
		
	}
	
	/**
	 * 
	 * @param utilisateur modifier
	 * @param id de l'utilisateur
	 */
	
	@RequestMapping(method=RequestMethod.PUT,value="/users/{id}") //mapping methode put pour mettre a jour des infos sur l'utilisateur
	public void updateUser(@RequestBody Utilisateur utilisateur,@PathVariable int id) {
		utilisateurService.updateUser(utilisateur,id);
		
	}
	/**
	 * 
	 * @param id de l'utilisateur à supprimer
	 */
	@RequestMapping(method=RequestMethod.DELETE,value="/users/{id}") //mapping delete pour supprimer un utilisateur
	public void deleteUser(@PathVariable int id) {
		utilisateurService.deleteUser(id);
		
	}
	
}
