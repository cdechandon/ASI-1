package com.cpe.springboot.card.model;

public class JsonModel {

}
