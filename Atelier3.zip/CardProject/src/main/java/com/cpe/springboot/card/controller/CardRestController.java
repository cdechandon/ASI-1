package com.cpe.springboot.card.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cpe.springboot.card.model.Card;


/*
 * Controller Restful -> gère les requêtes http du type methodes get, post, put et delete et renvoie une page JSON
 */

@RestController// Architecture du type REST
public class CardRestController {
	
	@Autowired // déclare le service qu'on utilise. Fait le lien entre le controller et une instance de CardService
	private CardService cardService;
	
	@RequestMapping("/cards") //fait appel à cette méthode quand l'URL contient /Cards à la fin.
	private List<Card> getAllCards() {
		
		return cardService.getAllCards();

	}
	
	@RequestMapping("/cards/{id}") // on rajoute une variable {id}
	private Card getCard(@PathVariable int id) { //@Pahtvariable récupère la variable passé en paramètre dans l'URL
		return cardService.getCard(String.valueOf(id));

	}
	
	@RequestMapping(method=RequestMethod.POST,value="/cards") // par défaut la méthode utilisée est get. POST rajoute une ligne d'info dans la table Cards
	public void addCard(@RequestBody Card card) {
		//card.setCardForUser(new CardForUser(card.getId(),userId));
		cardService.addCard(card);
	}
	
	@RequestMapping(method=RequestMethod.PUT,value="/cards/{id}") //Modifie les informations correspondant à l'id rentré
	public void updateCard(@RequestBody Card card,@PathVariable int id) {
		//card.setCardForUser(new CardForUser(id,userId));
		cardService.updateCard(card,id);
	}
	
	@RequestMapping(method=RequestMethod.DELETE,value="/cards/{id}")// Supprime la ligne correspondant à l'id
	public void deleteCard(@PathVariable int id) {
		cardService.deleteCard(String.valueOf(id));
	}
	

	

}
