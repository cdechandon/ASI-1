package com.cpe.springboot.InterfaceApp.service;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.cpe.springboot.InterfaceApp.model.Card;
import com.cpe.springboot.InterfaceApp.model.Utilisateur;



@Service 
public class InterfaceAppUserService {
	
	public Utilisateur getUser(int id) { 
		Utilisateur user=new Utilisateur();
		RestTemplate restTemplate = new RestTemplate();		
		String fooResourceUrl = "http://localhost:3030/users"; //URL de redirection
		fooResourceUrl+="/"+String.valueOf(id);
		try {	
		 user = restTemplate.getForObject(fooResourceUrl, Utilisateur.class); //méthode pour récup réponse
		}catch (RestClientException e) {
			e.printStackTrace();
		}
		return user;
	}
	
	public void addUser(Utilisateur user) { 
		RestTemplate restTemplate = new RestTemplate();		
		String fooResourceUrl = "http://localhost:3030/users"; //URL de redirection
		try {	
			restTemplate.postForObject(fooResourceUrl,user ,Utilisateur.class); //méthode pour récup réponse
		}catch (RestClientException e) {
			e.printStackTrace();
		}
	}
	
	public void updateUser(Utilisateur user, int id) {
		RestTemplate restTemplate = new RestTemplate();		
		String fooResourceUrl = "http://localhost:3030/users"; //URL de redirection
		fooResourceUrl+="/"+String.valueOf(id);
		try {	
			restTemplate.put(fooResourceUrl, user);
		}catch (RestClientException e) {
			e.printStackTrace();
		}
	}
	
	public void deleteUser(int id) {
		RestTemplate restTemplate = new RestTemplate();		
		String fooResourceUrl = "http://localhost:3030/users"; //URL de redirection
		fooResourceUrl+="/"+String.valueOf(id);
		try {	
			restTemplate.delete(fooResourceUrl);
		}catch (RestClientException e) {
			e.printStackTrace();
		}
		
	}
}
