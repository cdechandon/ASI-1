package com.cpe.springboot.InterfaceApp.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.cpe.springboot.InterfaceApp.model.Card;
import com.cpe.springboot.InterfaceApp.model.CardForUser;

@Service 
public class InterfaceAppCardForUserService {
	
	public List<CardForUser> getAllCardsForUser(int idUser) { 
		List<CardForUser> cardList=new ArrayList<>();
		CardForUser[] cardForUsertab=null	; //intialise la cardtab au cas où elle est vide
		RestTemplate restTemplate = new RestTemplate();		
		String fooResourceUrl = "http://localhost:4040/users/"+String.valueOf(idUser)+"/cards"; //URL de redirection
		try {	
			cardForUsertab = restTemplate.getForObject(fooResourceUrl, CardForUser[].class); //méthode pour récup réponse
		}catch (RestClientException e) {
			e.printStackTrace();
		}
		for (CardForUser cardForUser : cardForUsertab) { //on remplit la liste de cartes
			cardList.add(cardForUser);
		}
		return cardList;
	}

	public void addCardForUser(int userId,int cardId) { 
		//Card card=new Card();
		RestTemplate restTemplate = new RestTemplate();		
		String fooResourceUrl = "http://localhost:4040/users/"; //URL de redirection
		fooResourceUrl+=String.valueOf(userId)+"/cards/"+String.valueOf(cardId);
		try {	
			restTemplate.postForEntity(fooResourceUrl, null,null); //méthode pour récup réponse
		}catch (RestClientException e) {
			e.printStackTrace();
		}
	}
	
	public CardForUser getCardForUser(int idUser,int idCard) { 
		CardForUser cardForUser=new CardForUser();
		RestTemplate restTemplate = new RestTemplate();		
		String fooResourceUrl = "http://localhost:4040/users"; //URL de redirection
		fooResourceUrl+="/"+String.valueOf(idUser)+"/cards/"+String.valueOf(idCard);
		try {	
		 cardForUser = restTemplate.getForObject(fooResourceUrl, CardForUser.class); //méthode pour récup réponse
		}catch (RestClientException e) {
			e.printStackTrace();
		}
		return cardForUser;
	}
	
	public void updateCardForUser(Card card, int idUser,int idCard) {
		RestTemplate restTemplate = new RestTemplate();		
		String fooResourceUrl = "http://localhost:4040/users"; //URL de redirection
		fooResourceUrl+="/"+String.valueOf(idUser)+"/cards/"+String.valueOf(idCard);
		try {	
			//restTemplate.postForObject(fooResourceUrl,card ,Card.class); //méthode pour récup réponse
			restTemplate.put(fooResourceUrl, card);
		}catch (RestClientException e) {
			e.printStackTrace();
		}
		
	}

	public void deleteCardForUser(int idUser,int idCard) {
		RestTemplate restTemplate = new RestTemplate();		
		String fooResourceUrl = "http://localhost:4040/users/"+String.valueOf(idUser)+"/cards/"+String.valueOf(idCard); //URL de redirection
		try {	
			//restTemplate.postForObject(fooResourceUrl,card ,Card.class); //méthode pour récup réponse
			restTemplate.delete(fooResourceUrl);
		}catch (RestClientException e) {
			e.printStackTrace();
		}
		
	}
}
