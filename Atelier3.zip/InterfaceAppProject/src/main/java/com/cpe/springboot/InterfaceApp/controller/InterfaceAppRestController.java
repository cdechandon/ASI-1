package com.cpe.springboot.InterfaceApp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cpe.springboot.InterfaceApp.model.Card;
import com.cpe.springboot.InterfaceApp.model.CardForUser;
import com.cpe.springboot.InterfaceApp.model.Utilisateur;
import com.cpe.springboot.InterfaceApp.service.InterfaceAppCardForUserService;
import com.cpe.springboot.InterfaceApp.service.InterfaceAppCardService;
import com.cpe.springboot.InterfaceApp.service.InterfaceAppUserService;


@RestController// Architecture du type REST
public class InterfaceAppRestController {
	
		
		@Autowired // déclare le service qu'on utilise. Fait le lien entre le controller et une instance de CardService
		private InterfaceAppCardService interfaceAppCardService;
		
		@Autowired
		private InterfaceAppUserService interfaceAppUserService;
		
		@Autowired
		private InterfaceAppCardForUserService interfaceAppCardForUserService;
		
		@RequestMapping("/cards") //fait appel à cette méthode quand l'URL contient /Cards à la fin.
		private List<Card> getAllCards() {
			
			return interfaceAppCardService.getAllCards();

		}
		
		@RequestMapping("/card/{id}") //fait appel à cette méthode quand l'URL contient /Cards à la fin.
		private Card getCard(@PathVariable int id) {
			
			return interfaceAppCardService.getCard(id);

		}
		
		@RequestMapping(method=RequestMethod.POST,value="/card") //fait appel à cette méthode quand l'URL contient /Cards à la fin.
		private void addCard(@RequestBody Card card) {
			
			interfaceAppCardService.addCard(card);

		}
		@RequestMapping(method=RequestMethod.PUT,value="/card/{id}") //Modifie les informations correspondant à l'id rentré
		public void updateCard(@RequestBody Card card,@PathVariable int id) {
			//card.setCardForUser(new CardForUser(id,userId));
			interfaceAppCardService.updateCard(card,id);
		}
		@RequestMapping(method=RequestMethod.DELETE,value="/card/{id}")// Supprime la ligne correspondant à l'id
		public void deleteCard(@PathVariable int id) {
			interfaceAppCardService.deleteCard(id);
		}
		
		
		
		@RequestMapping("/user/{id}") //fait appel à cette méthode quand l'URL contient /Cards à la fin.
		private Utilisateur getUser(@PathVariable int id) {
			
			return interfaceAppUserService.getUser(id);

		}
		
		@RequestMapping(method=RequestMethod.POST,value="/user") //fait appel à cette méthode quand l'URL contient /Cards à la fin.
		private void addUser(@RequestBody Utilisateur user) {
			
			interfaceAppUserService.addUser(user);

		}
		@RequestMapping(method=RequestMethod.PUT,value="/user/{id}") //Modifie les informations correspondant à l'id rentré
		public void updateUser(@RequestBody Utilisateur utilisateur,@PathVariable int id) {
			//card.setCardForUser(new CardForUser(id,userId));
			interfaceAppUserService.updateUser(utilisateur,id);
		}
		@RequestMapping(method=RequestMethod.DELETE,value="/user/{id}")// Supprime la ligne correspondant à l'id
		public void deleteUser(@PathVariable int id) {
			interfaceAppUserService.deleteUser(id);
		}
		
		
		//Controller pour CardForUser
		
		@RequestMapping("/user/{idUser}/cards") //fait appel à cette méthode quand l'URL contient /Cards à la fin.
		private List<CardForUser> getAllCardsForUser(@PathVariable int idUser) {
			
			return interfaceAppCardForUserService.getAllCardsForUser(idUser);

		}
		
		@RequestMapping("/user/{idUser}/card/{idCard}") //fait appel à cette méthode quand l'URL contient /Cards à la fin.
		private CardForUser getCardForUser(@PathVariable int idUser,@PathVariable int idCard) {
			
			return interfaceAppCardForUserService.getCardForUser(idUser,idCard);

		}
		
		@RequestMapping(method=RequestMethod.POST,value="/user/{userId}/card/{idCard}") //fait appel à cette méthode quand l'URL contient /Cards à la fin.
		private void addCard(@PathVariable int userId,@PathVariable int idCard) {
			
			interfaceAppCardForUserService.addCardForUser(userId,idCard);

		}
		@RequestMapping(method=RequestMethod.PUT,value="/user/{idUser}/card/{idCard}") //Modifie les informations correspondant à l'id rentré
		public void updateCardForUser(@RequestBody Card card,@PathVariable int idUser,@PathVariable int idCard) {
			//card.setCardForUser(new CardForUser(id,userId));
			interfaceAppCardForUserService.updateCardForUser(card,idUser,idCard);
		}
		
		@RequestMapping(method=RequestMethod.DELETE,value="/user/{idUser}/card/{idCard}")// Supprime la ligne correspondant à l'id
		public void deleteCardForUser(@PathVariable int idUser,@PathVariable int idCard) {
			interfaceAppCardForUserService.deleteCardForUser(idUser,idCard);
		}
}
