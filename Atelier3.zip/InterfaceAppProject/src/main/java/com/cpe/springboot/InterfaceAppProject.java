package com.cpe.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InterfaceAppProject {

	public static void main(String[] args) {
		SpringApplication.run(InterfaceAppProject.class, args);
	}
}
