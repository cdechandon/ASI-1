package com.cpe.springboot.InterfaceApp.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.cpe.springboot.InterfaceApp.model.Card;

@Service 
public class InterfaceAppCardService {
	/**
	 * methode pour aller dans uservice cards
	 * @return list cards
	 */
	public List<Card> getAllCards() { 
		List<Card> cardList=new ArrayList<>();
		Card[] cardtab=null	; //intialise la cardtab au cas où elle est vide
		RestTemplate restTemplate = new RestTemplate();		
		String fooResourceUrl = "http://localhost:2020/cards"; //URL de redirection
		try {	
		 cardtab = restTemplate.getForObject(fooResourceUrl, Card[].class); //méthode pour récup réponse
		 
		 /*Card card=new Card();
		 restTemplate
				  .postForObject(fooResourceUrl,card,Card.class);
		*/
		}catch (RestClientException e) {
			e.printStackTrace();
		}
		for (Card card : cardtab) { //on remplit la liste de cartes
			cardList.add(card);
		}
		return cardList;
	}

	/**
	 * methode pour aller dans uservice cards
	 * @return une carte
	 */
	public Card getCard(int id) { 
		Card card=new Card();
		RestTemplate restTemplate = new RestTemplate();		
		String fooResourceUrl = "http://localhost:2020/cards"; //URL de redirection
		fooResourceUrl+="/"+String.valueOf(id);
		try {	
		 card = restTemplate.getForObject(fooResourceUrl, Card.class); //méthode pour récup réponse
		}catch (RestClientException e) {
			e.printStackTrace();
		}
		return card;
	}
	/**
	 * methode pour aller dans uservice cards
	 * @return une carte
	 */
	public void addCard(Card card) { 
		//Card card=new Card();
		RestTemplate restTemplate = new RestTemplate();		
		String fooResourceUrl = "http://localhost:2020/cards"; //URL de redirection
		//fooResourceUrl+="/"+String.valueOf(id);
		try {	
			restTemplate.postForObject(fooResourceUrl,card ,Card.class); //méthode pour récup réponse
		}catch (RestClientException e) {
			e.printStackTrace();
		}
	}

	public void updateCard(Card card, int id) {
		RestTemplate restTemplate = new RestTemplate();		
		String fooResourceUrl = "http://localhost:2020/cards"; //URL de redirection
		fooResourceUrl+="/"+String.valueOf(id);
		try {	
			//restTemplate.postForObject(fooResourceUrl,card ,Card.class); //méthode pour récup réponse
			restTemplate.put(fooResourceUrl, card);
		}catch (RestClientException e) {
			e.printStackTrace();
		}
		
	}

	public void deleteCard(int id) {
		RestTemplate restTemplate = new RestTemplate();		
		String fooResourceUrl = "http://localhost:2020/cards"; //URL de redirection
		fooResourceUrl+="/"+String.valueOf(id);
		try {	
			//restTemplate.postForObject(fooResourceUrl,card ,Card.class); //méthode pour récup réponse
			restTemplate.delete(fooResourceUrl);
		}catch (RestClientException e) {
			e.printStackTrace();
		}
		
	}
}
