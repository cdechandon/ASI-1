$(document ).ready(function(){
    $("#playButtonId").click(function(){
        alert("Play button clicked ");
        //TO DO
    });    
    $("#buyButtonId").click(function(){
        //alert("Buy button clicked ");
        document.location.href="./card.html";	//direction vers la nouvelle page html
        //TO DO
    });    
    $("#sellButtonId").click(function(){
        //alert("Sell button clicked ");
        document.location.href="./cardList.html"; //direction vers la nouvelle page html
        //TO DO
    });    
});

