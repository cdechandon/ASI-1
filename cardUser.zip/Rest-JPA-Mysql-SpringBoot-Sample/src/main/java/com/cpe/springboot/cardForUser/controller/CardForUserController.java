package com.cpe.springboot.cardForUser.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cpe.springboot.card.controller.CardService;
import com.cpe.springboot.card.model.Card;
import com.cpe.springboot.cardForUser.model.CardForUser;




/*
 * Controller Restful -> gère les requêtes http du type methodes get, post, put et delete et renvoie une page JSON
 */

@RestController
public class CardForUserController {
	
	private CardService cardService;
	@Autowired // déclare le service qu'on utilise. Fait le lien entre le controller et une instance de CardService
	private CardForUserService cardForUserService;
	

	@RequestMapping("/users/{id}/cards") //fait appel à cette méthode quand l'URL contient /Cards à la fin.
	private List<CardForUser> getAllCards(@PathVariable int id) {
		
		return cardForUserService.getAllCardForUser(id);

	}
	
	@RequestMapping("/users/{userId}/cards/{id}") // on rajoute une variable {id}
	private CardForUser getCard(@PathVariable int id,@PathVariable int userId ){ //@Pahtvariable récupère la variable passé en paramètre dans l'URL
		return cardForUserService.getCardForUser(userId,id);

	}
	
	@RequestMapping(method=RequestMethod.POST,value="/users/{userId}/cards/{idCard}") // par défaut la méthode utilisée est get. POST rajoute une ligne d'info dans la table Cards
	public void addCard(@PathVariable int userId,@PathVariable int idCard) {
		Card card = cardService.getCard(String.valueOf(idCard));
		CardForUser carte = new CardForUser(card,userId);
		cardForUserService.addCardForUser(carte);
	}
	
	@RequestMapping(method=RequestMethod.PUT,value="/users/{userId}/cards/{id}") //Modifie les informations correspondant à l'id rentré
	public void updateCard(@RequestBody Card card,@PathVariable int id,@PathVariable int userId) {
		int idCardUser=cardForUserService.getCardForUser(userId, id).getIdCardUser();
		CardForUser carte = new CardForUser(idCardUser,card,userId);
		cardForUserService.updateCardForUser(carte,idCardUser);
	}
	
	@RequestMapping(method=RequestMethod.DELETE,value="/users/{userId}/cards/{id}")// Supprime la ligne correspondant à l'id
	public void deleteCard(@PathVariable int userId,@PathVariable int id) {
		int idCarte=cardForUserService.getCardForUser(userId,id).getIdCardUser();
		cardForUserService.deleteCardForUser(idCarte);
	}
	

	

}
