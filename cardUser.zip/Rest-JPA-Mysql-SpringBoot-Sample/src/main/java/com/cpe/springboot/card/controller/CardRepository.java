package com.cpe.springboot.card.controller;

import org.springframework.data.repository.CrudRepository;

import com.cpe.springboot.card.model.Card;

/*
 * Crud permet de réaliser des opérations sur la BD
 * CrudRepository est une interface qui permet de faire des opérations comme ajouter une ligne dans la table Card en fonction de son id
 */
public interface CardRepository extends CrudRepository<Card, Integer> {// Nous alons creer un repertoire de carte identifiable par leur id
	//public List<Card> findByUtilisateurId(String id);// Nous declarons la methode ci pour trouver un utilisateur
	// cette methode renvoie la liste de carte correspondant a l'id de l'utilisateur
}
