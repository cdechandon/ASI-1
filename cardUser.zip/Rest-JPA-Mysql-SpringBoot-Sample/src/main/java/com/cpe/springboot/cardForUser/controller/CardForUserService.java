package com.cpe.springboot.cardForUser.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cpe.springboot.cardForUser.model.CardForUser;


@Service
public class CardForUserService {
	
	@Autowired // nous met en lien avec le repertoire de carte connectee a la db
	private CardForUserRepository cardForUserRepository;
	
	
	public List<CardForUser> getAllCardForUser(int id){
		List<CardForUser> cardForUser = new ArrayList<>();
		cardForUserRepository.findByIdU(id)
		.forEach(cardForUser::add); 
		
		return cardForUser;
		
	}
	
	
	public CardForUser getCardForUser(int idUser,int idCard) {
		List<CardForUser> listeCarte = getAllCardForUser(idUser);
		CardForUser carte = new CardForUser(idUser);

		for(int i=0;i<listeCarte.size();i++) 
		{
			if (listeCarte.get(i).getId()==idCard)
			{
				carte = listeCarte.get(i);
			}
		}
		return carte;
	}
	
	

	public void addCardForUser(CardForUser cardForUser) {
		cardForUserRepository.save(cardForUser);
		
	}

	public void updateCardForUser(CardForUser cardForUser,int idCardUser) {
		cardForUserRepository.save(cardForUser);
		
	}

	public void deleteCardForUser(int id) {
		
		cardForUserRepository.delete(id);
	}

}
