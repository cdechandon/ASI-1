package com.cpe.springboot.cardForUser.controller;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.cpe.springboot.cardForUser.model.CardForUser;

/*
 * Crud permet de réaliser des opérations sur la BD
 * CrudRepository est une interface qui permet de faire des opérations comme ajouter une ligne dans la table Card en fonction de son id
 */

public interface CardForUserRepository extends CrudRepository<CardForUser, Integer> {

	public List<CardForUser> findByIdU(int idU);

}

