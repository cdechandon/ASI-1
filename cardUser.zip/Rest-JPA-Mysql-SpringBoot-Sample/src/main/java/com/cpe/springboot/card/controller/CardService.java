package com.cpe.springboot.card.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cpe.springboot.card.model.Card;



@Service // L'application Spring Boot sait que cette classe correspond à un service 
public class CardService {

	@Autowired // nous met en lien avec le repertoire de carte connectee a la db
	private CardRepository cardRepository;

	public Card getCard(String id) { // Retourne un seul élément de CardRepository en fonction de l'id rentré en paramètre
		return cardRepository.findOne(Integer.valueOf(id));
	}
}
