package com.cpe.springboot.utilisateur.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity // a notre DB comment creer la table
public class Utilisateur {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
    private int id;

 
 	public Utilisateur(int id) {
 		this.id = id;
 	}

	public Utilisateur() {
		//this.id=Integer.valueOf(UUID.randomUUID().toString());
	}
	
	public void setId(int id) {
		this.id = id;			
	}
}