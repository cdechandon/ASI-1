package com.cpe.springboot.card.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cpe.springboot.card.model.Card;



/*
 * Controller Restful -> gère les requêtes http du type methodes get, post, put et delete et renvoie une page JSON
 */

@RestController
public class CardRestController {
	
	@Autowired // déclare le service qu'on utilise. Fait le lien entre le controller et une instance de CardService
	private CardService cardService;
	
	
	@RequestMapping("/cards/{id}") // on rajoute une variable {id}
	private Card getCard(@PathVariable int id) 
	{ //@Pahtvariable récupère la variable passé en paramètre dans l'URL
		return cardService.getCard(String.valueOf(id));
	}
}
