package com.cpe.springboot.card.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cpe.springboot.card.model.Card;



@Service // L'application Spring Boot sait que cette classe correspond à un service 
public class CardService {

	@Autowired // nous met en lien avec le repertoire de carte connectee a la db
	private CardRepository cardRepository;

	/**
	 * 
	 * @return toute les cartes de la DB card
	 */
	public List<Card> getAllCards() { // Rajoute dans la List Cards tous les éléments de l'objet CardRepository
		List<Card> cards = new ArrayList<>();
		cardRepository.findAll()// On recupere une liste de carte dans le repository correspondant au bon utilisateur
		.forEach(cards::add);// on rajoute chaque cartes
		return cards;

	}

	/**
	 * 
	 * @param id de la carte
	 * @return la carte avec l'id donné
	 */
	public Card getCard(String id) { // Retourne un seul élément de CardRepository en fonction de l'id rentré en paramètre
		return cardRepository.findOne(Integer.valueOf(id));
	}

	/**
	 * 
	 * @param Card a ajouter
	 */
	public void addCard(Card Card) { // Rajoute un objet de type Card dans le cardRepository
		cardRepository.save(Card);
	}

	/**
	 * 
	 * @param Card à modifier
	 * @param id de celle-ci
	 */
	public void updateCard(Card Card,int id) { // met a jour une carte ici si la carte est deja existante elle va juste modifier les informations
		cardRepository.save(Card);

	}

	/**
	 * 
	 * @param id de la carte à supprimer
	 */
	public void deleteCard(String id) { // supprime une carte via son id
		cardRepository.delete(Integer.valueOf(id));
	}


	

}
