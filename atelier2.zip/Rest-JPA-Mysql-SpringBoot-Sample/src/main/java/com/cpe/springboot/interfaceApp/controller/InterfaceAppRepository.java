package com.cpe.springboot.interfaceApp.controller;

public class InterfaceAppRepository {

}
