package com.cpe.springboot.cardForUser.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cpe.springboot.card.controller.CardRepository;
import com.cpe.springboot.card.model.Card;
import com.cpe.springboot.cardForUser.model.CardForUser;
import com.cpe.springboot.utilisateur.controler.UtilisateurRepository;
import com.cpe.springboot.utilisateur.controler.UtilisateurService;
import com.cpe.springboot.utilisateur.model.Utilisateur;


@Service
public class CardForUserService {
	
	@Autowired // nous met en lien avec le repertoire de carte connectee a la db
	private CardForUserRepository cardForUserRepository;
	
	@Autowired
	private UtilisateurService utilisateurService;
	
	@Autowired
	private CardRepository cardRepository;
	
	/**
	 * 
	 * @param id de l'utilisateur
	 * @return les cartes de l'utilisateur
	 */
	public List<CardForUser> getAllCardForUser(int id){
		List<CardForUser> cardForUser = new ArrayList<>();
		cardForUserRepository.findByUtilisateurId(id)
		.forEach(cardForUser::add); 
		
		return cardForUser;
		
	}
	/**
	 * 
	 * @param idUser
	 * @param idCard
	 * @return la carte de l'utilisateur
	 */
	public CardForUser getCardForUser(int idUser,int idCard) {
		List<CardForUser> liste = getAllCardForUser(idUser);
				for(int i=0;i<liste.size();i++) {
			if (liste.get(i).getId()==idCard) {
				return liste.get(i);
			}
		}
		CardForUser carte=new CardForUser(utilisateurService.getUser(idUser));

		return carte;
	}
	
	
	/**
	 * 
	 * @param cardForUser est la carte rajoutée à la DB
	 */
	public void addCardForUser(CardForUser cardForUser) {
		cardForUserRepository.save(cardForUser);
		
	}

	public void updateCardForUser(CardForUser cardForUser,int idCardUser) {
		cardForUserRepository.save(cardForUser);
		
	}

	public void deleteCardForUser(int id) {
		
		cardForUserRepository.delete(id);
	}

}
