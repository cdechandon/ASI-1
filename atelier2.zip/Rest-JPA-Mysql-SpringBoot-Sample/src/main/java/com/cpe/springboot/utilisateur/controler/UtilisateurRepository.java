package com.cpe.springboot.utilisateur.controler;

import org.springframework.data.repository.CrudRepository;

import com.cpe.springboot.utilisateur.model.Utilisateur;

/*
 * Crud permet de réaliser des opérations sur la BD
 * CrudRepository est une interface qui permet de faire des opérations comme ajouter une ligne dans la table Card en fonction de son id
 */

public interface UtilisateurRepository extends CrudRepository<Utilisateur, Integer> {



}
