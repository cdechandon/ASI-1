package com.cpe.springboot.interfaceApp.controller;

public class InterfaceAppService {

}
