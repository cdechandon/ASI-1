package com.cpe.springboot.interfaceApp.model;

import com.cpe.springboot.card.model.Card;
import com.cpe.springboot.cardForUser.model.CardForUser;
import com.cpe.springboot.utilisateur.model.Utilisateur;

public class InterfaceAppModel {
	
	private Utilisateur utilisateur;
	private Card card;
	private CardForUser cardForUser;
	
	public InterfaceAppModel(Utilisateur uti) {
		this.utilisateur=uti;
		this.setCard(null);
		this.setCardForUser(null);
	}
	
	public InterfaceAppModel(Card card) {
		this.card=card;
		this.setCardForUser(null);
		this.setUtilisateur(null);
		
	}
	
	public InterfaceAppModel(CardForUser cardForU) {
		this.cardForUser=cardForU;
		this.setCard(null);
		this.setUtilisateur(null);
	}
	
	public Utilisateur getUtilisateur() {
		return utilisateur;
	}
	public void setUtilisateur(Utilisateur utilisateur) {
		this.utilisateur = utilisateur;
	}
	public Card getCard() {
		return card;
	}
	public void setCard(Card card) {
		this.card = card;
	}
	public CardForUser getCardForUser() {
		return cardForUser;
	}
	public void setCardForUser(CardForUser cardForUser) {
		this.cardForUser = cardForUser;
	}
	
	

}
